require("./bot.js");

